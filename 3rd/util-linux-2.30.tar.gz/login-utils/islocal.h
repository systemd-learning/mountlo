extern int is_local(const char *user);
